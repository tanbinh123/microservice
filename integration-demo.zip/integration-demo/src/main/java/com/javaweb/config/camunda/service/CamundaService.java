package com.javaweb.config.camunda.service;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.camunda.bpm.engine.repository.Resource;

import com.javaweb.eo.camunda.AssigneeTaskRequest;
import com.javaweb.eo.camunda.DelegateTaskRequest;
import com.javaweb.eo.camunda.DeploymentListRequest;
import com.javaweb.eo.camunda.DeploymentListResponse;
import com.javaweb.eo.camunda.ExecuteTaskListRequest;
import com.javaweb.eo.camunda.FinishDelegateTaskRequest;
import com.javaweb.eo.camunda.HistoricActivityInstanceListRequest;
import com.javaweb.eo.camunda.Page;
import com.javaweb.eo.camunda.ProcessDefinitionListRequest;
import com.javaweb.eo.camunda.ProcessInstanceByIdResponse;
import com.javaweb.eo.camunda.ProcessInstanceHistoryListRequest;
import com.javaweb.eo.camunda.ProcessInstanceListRequest;
import com.javaweb.eo.camunda.TaskBackRequest;
import com.javaweb.eo.camunda.TaskHistoryListRequest;

public interface CamundaService {
	
	/**
	 * 部署BPMN流程图
	 * @param resourceName 流程图（文件）名称
	 * @param inputStream 流程图XML输入流
	 * @return Deployment 部署信息
	 * @throws Exception 主要是部署流程图XML时的解析异常
	 * @see https://stackoverflow.com/questions/63692725/camunda-load-bpmn-xml-from-database
	 * @see https://stackoverflow.com/questions/44518759/camunda-process-definition-deployment-via-api
	 */
	public DeploymentListResponse deploymentBpmnXml(String resourceName,InputStream inputStream);
	
	/**
	 * 部署BPMN流程图
	 * @param resourceName 流程图（文件）名称
	 * @param xmlContent 流程图XML内容
	 * @return Deployment 部署信息
	 * @throws Exception 主要是部署流程图XML时的解析异常
	 * @see https://stackoverflow.com/questions/63692725/camunda-load-bpmn-xml-from-database
	 * @see https://stackoverflow.com/questions/44518759/camunda-process-definition-deployment-via-api
	 */
	public DeploymentListResponse deploymentBpmnXml(String resourceName,String xmlContent);
	
	/**
	 * 部署信息列表
	 * @param deploymentListRequest 带分页的查询请求参数
	 * @return Page 带分页的查询响应结果
	 * @throws Exception 异常
	 */
	public Page listDeployment(DeploymentListRequest deploymentListRequest);
	
	/**
	 * 删除流程部署
	 * @param deploymentId 部署ID
	 * @throws Exception 异常
	 */
	public void deleteDeployment(String deploymentId);
	
	/**
	 * 流程定义列表
	 * @param processDefinitionListRequest 带分页的查询请求参数
	 * @return Page 带分页的查询响应结果
	 * @throws Exception 异常
	 */
	public Page listProcessDefinition(ProcessDefinitionListRequest processDefinitionListRequest);
	
	/**
	 * 删除流程定义
	 * @param processDefinitionId 流程定义ID
	 * @throws Exception 异常
	 */
	public void deleteProcessDefinition(String processDefinitionId);
	
	/**
	 * 启动流程实例
	 * @param processDefinitionId 流程定义ID
	 * @param businessKey 自定义业务key
	 * @param map 流程上的各种参数定义（如会签人员列表等）
	 * @return ProcessInstanceByIdResponse 流程实例信息
	 * @throws Exception 异常
	 */
	public ProcessInstanceByIdResponse startProcessInstanceById(String processDefinitionId,String businessKey,Map<String,Object> map);
	
	/**
	 * 启动流程实例
	 * @param processDefinitionKey 流程图ID（就是id="Process_1wgrhz1"）
	 * @param map 流程上的各种参数定义（如会签人员列表等）
	 * @return ProcessInstanceByIdResponse 流程实例信息
	 * @throws Exception 异常
	 */
	public ProcessInstanceByIdResponse startProcessInstanceByKey(String processDefinitionKey,Map<String,Object> map);
	
	/**
	 * 流程实例列表
	 * @param processInstanceListRequest 带分页的查询请求参数
	 * @return Page 带分页的查询响应结果
	 * @throws Exception 异常
	 */
	public Page listProcessInstance(ProcessInstanceListRequest processInstanceListRequest);
	
	/**
	 * 执行中任务列表（需启动流程实例才会有）
	 * @param executeTaskListRequest 带分页的查询请求参数
	 * @return Page 带分页的查询响应结果
	 * @throws Exception 异常
	 */
	public Page listExecuteTask(ExecuteTaskListRequest executeTaskListRequest);
	
	/**
	 * 获取任务对应的参数（一般为上一步传递过来的参数）
	 * @param taskId 任务ID
	 * @return Map<String,Object> 任务对应的参数（一般为上一步传递过来的参数）
	 * @throws Exception 异常
	 */
	public Map<String,Object> getTaskVariables(String taskId);
	
	/**
	 * 完成流程任务
	 * @param taskId 任务ID（执行中任务列表的ID）
	 * @param map 流程上的各种参数定义（如会签人员列表等）
	 * @throws Exception 异常
	 */
	public void completeTask(String taskId,Map<String,Object> map);
	
	/**
	 * 激活/挂起流程实例
	 * @param processInstanceId 流程实例ID
	 * @param type 类型（1：激活任务；2：挂起任务）
	 * @throws Exception 异常
	 */
	public void activeOrSuspendProcessInstance(String processInstanceId,int type);
	
	/**
	 * 历史实例列表
	 * @param processInstanceHistoryListRequest 带分页的查询请求参数
	 * @return Page 带分页的查询响应结果
	 * @throws Exception 异常
	 */
	public Page listHistoryProcessInstance(ProcessInstanceHistoryListRequest processInstanceHistoryListRequest);
	
	/**
	 * 历史任务列表
	 * @param taskHistoryListRequest 带分页的查询请求参数
	 * @return Page 带分页的查询响应结果
	 * @throws Exception 异常
	 */
	public Page listHistoryTask(TaskHistoryListRequest taskHistoryListRequest);
	
	/**
	 * 历史激活实例信息列表（常与回退等操作联合使用）
	 * @param historicActivityInstanceListRequest  带分页的查询请求参数
	 * @return Page 带分页的查询响应结果
	 * @throws Exception Exception 异常
	 */
	public Page listHistoricActivityInstance(HistoricActivityInstanceListRequest historicActivityInstanceListRequest);
	
	/**
	 * 委派（委托）任务
	 * @param delegateTaskRequest 请求参数
	 * @throws Exception 异常
	 */
	public void delegateTask(DelegateTaskRequest delegateTaskRequest);
	
	/**
	 * 完成委派（委托）任务
	 * @param finishDelegateTaskRequest 请求参数
	 * @throws Exception 异常
	 */
	public void finishDelegateTask(FinishDelegateTaskRequest finishDelegateTaskRequest);
	
	/**
	 * 转办（转交）任务
	 * @param delegateTaskRequest 请求参数
	 * @throws Exception 异常
	 */
	public void assigneeTask(AssigneeTaskRequest assigneeTaskRequest);
	
	/**
	 * 获取流程部署资源（一般为bpmn文件）
	 * @param deploymentId
	 * @return List<Resource> 资源列表
	 * @throws Exception 异常
	 */
	public List<Resource> getDeploymentResources(String deploymentId);
	
	/**
	 * 任务回退
	 * @param taskBackRequest 请求参数
	 * @throws Exception 异常
	 */
	public void taskBack(TaskBackRequest taskBackRequest);
	
}
