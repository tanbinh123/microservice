package com.javaweb.config.desensitization.impl;

import com.javaweb.config.desensitization.DesensitizationHandler;

//姓名
public class NameImpl implements DesensitizationHandler {

	public String handleData(String str) {
		return "姓名";
	}

}
