package com.javaweb.config.desensitization;

import com.fasterxml.jackson.databind.introspect.Annotated;
import com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector;

public class DesensitizationAnnotationIntrospector extends NopAnnotationIntrospector  {

	private static final long serialVersionUID = -8700912658164124424L;

	public Object findSerializer(Annotated annotated){
		DesensitizationAnnotation desensitizationAnnotation = annotated.getAnnotation(DesensitizationAnnotation.class);
        if(desensitizationAnnotation!=null){
            return new DesensitizationDataSerializer(desensitizationAnnotation)/*DesensitizationDataSerializer.class*/;
        }
        return null;
    }
	
	public Object findDeserializer(Annotated annotated){
		DesensitizationAnnotation desensitizationAnnotation = annotated.getAnnotation(DesensitizationAnnotation.class);
        if(desensitizationAnnotation!=null){
            return new DesensitizationDataDeserializer(desensitizationAnnotation)/*DesensitizationDataDeserializer.class*/;
        }
        return null;
    }
	
}
