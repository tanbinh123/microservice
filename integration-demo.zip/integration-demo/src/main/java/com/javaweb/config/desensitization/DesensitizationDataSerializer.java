package com.javaweb.config.desensitization;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

public class DesensitizationDataSerializer extends StdSerializer<String> {

	private static final long serialVersionUID = -9152497311277865560L;
	
	private DesensitizationAnnotation desensitizationAnnotation;
	
	public DesensitizationDataSerializer() {
        super(String.class);
    }
	
	public DesensitizationDataSerializer(DesensitizationAnnotation desensitizationAnnotation) {
		super(String.class);
		this.desensitizationAnnotation = desensitizationAnnotation;
    }
	
	public DesensitizationAnnotation getDesensitizationAnnotation() {
		return desensitizationAnnotation;
	}

	public void setDesensitizationAnnotation(DesensitizationAnnotation desensitizationAnnotation) {
		this.desensitizationAnnotation = desensitizationAnnotation;
	}

	public void serialize(String value,JsonGenerator jsonGenerator,SerializerProvider serializerProvider) throws IOException {
		DesensitizationHandler desensitizationHandler = ObjectMapperSingleton.MAP.get(desensitizationAnnotation.type());
		if(desensitizationHandler==null){
			jsonGenerator.writeString(value);
		}else{
			jsonGenerator.writeString(desensitizationHandler.handleData(value));
		}
    }
	
}
