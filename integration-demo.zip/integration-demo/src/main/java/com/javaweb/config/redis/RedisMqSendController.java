package com.javaweb.config.redis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RedisMqSendController {
	
	@Autowired
	@Qualifier("redisTemplate1")
	protected StringRedisTemplate stringRedisTemplate;

	@GetMapping("/send")
	public String send() {
		stringRedisTemplate.convertAndSend("MyTopic","Hello World");
		return "success";
	}
	
}
