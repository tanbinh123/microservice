package com.javaweb.config.camunda.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.camunda.bpm.engine.history.HistoricActivityInstance;
import org.camunda.bpm.engine.history.HistoricActivityInstanceQuery;
import org.camunda.bpm.engine.history.HistoricProcessInstance;
import org.camunda.bpm.engine.history.HistoricProcessInstanceQuery;
import org.camunda.bpm.engine.history.HistoricTaskInstance;
import org.camunda.bpm.engine.history.HistoricTaskInstanceQuery;
import org.camunda.bpm.engine.repository.Deployment;
import org.camunda.bpm.engine.repository.DeploymentQuery;
import org.camunda.bpm.engine.repository.ProcessDefinition;
import org.camunda.bpm.engine.repository.ProcessDefinitionQuery;
import org.camunda.bpm.engine.repository.Resource;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.bpm.engine.runtime.ProcessInstanceModificationBuilder;
import org.camunda.bpm.engine.runtime.ProcessInstanceModificationInstantiationBuilder;
import org.camunda.bpm.engine.runtime.ProcessInstanceQuery;
import org.camunda.bpm.engine.task.IdentityLink;
import org.camunda.bpm.engine.task.Task;
import org.camunda.bpm.engine.task.TaskQuery;
import org.springframework.stereotype.Service;

import com.javaweb.base.BaseService;
import com.javaweb.eo.camunda.AssigneeTaskRequest;
import com.javaweb.eo.camunda.DelegateTaskRequest;
import com.javaweb.eo.camunda.DeploymentListRequest;
import com.javaweb.eo.camunda.DeploymentListResponse;
import com.javaweb.eo.camunda.ExecuteTaskListRequest;
import com.javaweb.eo.camunda.ExecuteTaskListResponse;
import com.javaweb.eo.camunda.FinishDelegateTaskRequest;
import com.javaweb.eo.camunda.HistoricActivityInstanceListRequest;
import com.javaweb.eo.camunda.HistoricActivityInstanceListResponse;
import com.javaweb.eo.camunda.Page;
import com.javaweb.eo.camunda.ProcessDefinitionListRequest;
import com.javaweb.eo.camunda.ProcessDefinitionListResponse;
import com.javaweb.eo.camunda.ProcessInstanceByIdResponse;
import com.javaweb.eo.camunda.ProcessInstanceHistoryListRequest;
import com.javaweb.eo.camunda.ProcessInstanceHistoryListResponse;
import com.javaweb.eo.camunda.ProcessInstanceListRequest;
import com.javaweb.eo.camunda.ProcessInstanceListResponse;
import com.javaweb.eo.camunda.TaskBackRequest;
import com.javaweb.eo.camunda.TaskHistoryListRequest;
import com.javaweb.eo.camunda.TaskHistoryListResponse;
import com.javaweb.util.core.DateUtil;

@Service("camundaServiceImpl")
public class CamundaServiceImpl extends BaseService implements CamundaService {
	
	public DeploymentListResponse deploymentBpmnXml(String resourceName,InputStream inputStream){
		Deployment deployment = repositoryService.createDeployment().name(resourceName).addInputStream(resourceName,inputStream).activateProcessDefinitionsOn(new Date()).deploy();
		try{
			if(inputStream!=null){
				inputStream.close();
			}
		}catch(IOException e){
			//do nothing
		}
		DeploymentListResponse deploymentListResponse = new DeploymentListResponse();
		deploymentListResponse.setId(deployment.getId());
		deploymentListResponse.setName(deployment.getName());
		deploymentListResponse.setDeploymentTime(DateUtil.dateToLocalDateTime(deployment.getDeploymentTime()).format(DateTimeFormatter.ofPattern(DateUtil.DEFAULT_DATETIME_PATTERN)));
		deploymentListResponse.setSource(deployment.getSource());
		deploymentListResponse.setTenantId(deployment.getTenantId());
		return deploymentListResponse;
	}

	public DeploymentListResponse deploymentBpmnXml(String resourceName,String xmlContent){
		InputStream inputStream = new ByteArrayInputStream(xmlContent.getBytes());
		return deploymentBpmnXml(resourceName,inputStream);
	}
	
	public Page listDeployment(DeploymentListRequest deploymentListRequest){
		String deploymentId = deploymentListRequest.getDeploymentId();
		String deploymentName = deploymentListRequest.getDeploymentName();
		int firstResult = (deploymentListRequest.getCurrentPage()-1)*deploymentListRequest.getPageSize();
		int maxResults = deploymentListRequest.getPageSize();
		DeploymentQuery deploymentQuery = null;
		if(deploymentId==null||"".equals(deploymentId.trim())){
			deploymentQuery = repositoryService.createDeploymentQuery();
		}else{
			deploymentQuery = repositoryService.createDeploymentQuery().deploymentId(deploymentId);
		}
		if((deploymentName!=null)&&(!"".equals(deploymentName.trim()))){
			deploymentQuery.deploymentNameLike(deploymentName);
		}
		List<Deployment> list = deploymentQuery.listPage(firstResult,maxResults);
		List<DeploymentListResponse> deploymentListResponseList = new ArrayList<>();
		for(int i=0;i<list.size();i++){
			Deployment deployment = list.get(i);
			DeploymentListResponse deploymentListResponse = new DeploymentListResponse();
			deploymentListResponse.setId(deployment.getId());
			deploymentListResponse.setName(deployment.getName());
			deploymentListResponse.setDeploymentTime(DateUtil.dateToLocalDateTime(deployment.getDeploymentTime()).format(DateTimeFormatter.ofPattern(DateUtil.DEFAULT_DATETIME_PATTERN)));
			deploymentListResponse.setSource(deployment.getSource());
			deploymentListResponse.setTenantId(deployment.getTenantId());
			deploymentListResponseList.add(deploymentListResponse);
		}
		return new Page(deploymentListRequest,deploymentListResponseList,deploymentQuery.count());
	}

	public void deleteDeployment(String deploymentId){
		long count = repositoryService.createDeploymentQuery().deploymentId(deploymentId).count();
		if(count<=0){
			throw new RuntimeException("所要删除的流程部署不存在");
		}
		repositoryService.deleteDeployment(deploymentId,true);
	}
	
	public Page listProcessDefinition(ProcessDefinitionListRequest processDefinitionListRequest){
		String deploymentId = processDefinitionListRequest.getDeploymentId();
		String key = processDefinitionListRequest.getKey();
		int firstResult = (processDefinitionListRequest.getCurrentPage()-1)*processDefinitionListRequest.getPageSize();
		int maxResults = processDefinitionListRequest.getPageSize();
		ProcessDefinitionQuery processDefinitionQuery = null;
		if(deploymentId==null||"".equals(deploymentId.trim())){
			processDefinitionQuery = repositoryService.createProcessDefinitionQuery();
		}else{
			processDefinitionQuery = repositoryService.createProcessDefinitionQuery().deploymentId(deploymentId);
		}
		if((key!=null)&&(!"".equals(key.trim()))){
			processDefinitionQuery.processDefinitionKey(key);
		}
		processDefinitionQuery.orderByProcessDefinitionKey().asc().orderByProcessDefinitionVersion().desc();
		List<ProcessDefinition> list = processDefinitionQuery.listPage(firstResult,maxResults);
		List<ProcessDefinitionListResponse> processDefinitionListResponseList = new ArrayList<>();
		for(int i=0;i<list.size();i++){
			ProcessDefinition processDefinition = list.get(i);
			ProcessDefinitionListResponse processDefinitionListResponse = new ProcessDefinitionListResponse();
			processDefinitionListResponse.setId(processDefinition.getId());
			processDefinitionListResponse.setDeploymentId(processDefinition.getDeploymentId());
			processDefinitionListResponse.setKey(processDefinition.getKey());
			processDefinitionListResponse.setVersion(processDefinition.getVersion());
			processDefinitionListResponseList.add(processDefinitionListResponse);
		}
		return new Page(processDefinitionListRequest,processDefinitionListResponseList,processDefinitionQuery.count());
	}
	
	public void deleteProcessDefinition(String processDefinitionId){
		long count = repositoryService.createProcessDefinitionQuery().processDefinitionId(processDefinitionId).count();
		if(count<=0){
			throw new RuntimeException("所要删除的流程定义不存在");
		}
		repositoryService.deleteProcessDefinition(processDefinitionId,true);
	}

	public ProcessInstanceByIdResponse startProcessInstanceById(String processDefinitionId,String businessKey,Map<String,Object> map){
		long count = repositoryService.createProcessDefinitionQuery().processDefinitionId(processDefinitionId).count();
		if(count<=0){
			throw new RuntimeException("所要启动的流程定义不存在");
		}
		ProcessInstance processInstance = runtimeService.startProcessInstanceById(processDefinitionId,businessKey,map);
		ProcessInstanceByIdResponse processInstanceByIdResponse = new ProcessInstanceByIdResponse();
		processInstanceByIdResponse.setId(processInstance.getId());
		processInstanceByIdResponse.setProcessDefinitionId(processInstance.getProcessDefinitionId());
		processInstanceByIdResponse.setProcessInstanceId(processInstance.getProcessInstanceId());
		processInstanceByIdResponse.setBusinessKey(processInstance.getBusinessKey());
		return processInstanceByIdResponse;
	}
	
	public ProcessInstanceByIdResponse startProcessInstanceByKey(String processDefinitionKey,Map<String,Object> map){
		long count = repositoryService.createProcessDefinitionQuery().processDefinitionKey(processDefinitionKey).count();
		if(count<=0){
			throw new RuntimeException("所要启动的流程定义不存在");
		}
		ProcessInstance processInstance = runtimeService.startProcessInstanceByKey(processDefinitionKey,map);
		ProcessInstanceByIdResponse processInstanceByIdResponse = new ProcessInstanceByIdResponse();
		processInstanceByIdResponse.setId(processInstance.getId());
		processInstanceByIdResponse.setProcessDefinitionId(processInstance.getProcessDefinitionId());
		processInstanceByIdResponse.setProcessInstanceId(processInstance.getProcessInstanceId());
		processInstanceByIdResponse.setBusinessKey(processInstance.getBusinessKey());
		return processInstanceByIdResponse;
	}
	
	public Page listProcessInstance(ProcessInstanceListRequest processInstanceListRequest){
		String processInstanceId = processInstanceListRequest.getProcessInstanceId();
		int firstResult = (processInstanceListRequest.getCurrentPage()-1)*processInstanceListRequest.getPageSize();
		int maxResults = processInstanceListRequest.getPageSize();
		ProcessInstanceQuery processInstanceQuery = null;
		if(processInstanceId==null||"".equals(processInstanceId.trim())){
			processInstanceQuery = runtimeService.createProcessInstanceQuery();
		}else{
			processInstanceQuery = runtimeService.createProcessInstanceQuery().processInstanceId(processInstanceId);
		}
		List<ProcessInstance> list = processInstanceQuery.listPage(firstResult,maxResults);
		List<ProcessInstanceListResponse> processInstanceListResponseList = new ArrayList<>();
		for(int i=0;i<list.size();i++){
			ProcessInstance processInstance = list.get(i);
			ProcessInstanceListResponse processInstanceListResponse = new ProcessInstanceListResponse();
			processInstanceListResponse.setBusinessKey(processInstance.getBusinessKey());
			processInstanceListResponse.setCaseInstanceId(processInstance.getCaseInstanceId());
			processInstanceListResponse.setId(processInstance.getId());
			processInstanceListResponse.setProcessDefinitionId(processInstance.getProcessDefinitionId());
			processInstanceListResponse.setProcessInstanceId(processInstance.getProcessInstanceId());
			processInstanceListResponse.setSuspendedFlag(processInstance.isSuspended());
			processInstanceListResponseList.add(processInstanceListResponse);
		}
		return new Page(processInstanceListRequest,processInstanceListResponseList,processInstanceQuery.count());
	}

	public Page listExecuteTask(ExecuteTaskListRequest executeTaskListRequest){
		String taskId = executeTaskListRequest.getTaskId();
		String taskName = executeTaskListRequest.getTaskName();
		String processInstanceId = executeTaskListRequest.getProcessInstanceId();
		int firstResult = (executeTaskListRequest.getCurrentPage()-1)*executeTaskListRequest.getPageSize();
		int maxResults = executeTaskListRequest.getPageSize();
		TaskQuery taskQuery = null;
		if(taskId==null||"".equals(taskId.trim())){
			taskQuery = taskService.createTaskQuery();
		}else{
			taskQuery = taskService.createTaskQuery().taskId(taskId);
		}
		if((taskName!=null)&&(!"".equals(taskName.trim()))){
			taskQuery = taskService.createTaskQuery().taskNameLike(taskName);
		}
		if((processInstanceId!=null)&&(!"".equals(processInstanceId.trim()))){
			taskQuery.processInstanceId(processInstanceId);
		}
		List<Task> list = taskQuery.listPage(firstResult,maxResults);
		List<ExecuteTaskListResponse> executeTaskListResponseList = new ArrayList<>();
		for(int i=0;i<list.size();i++){
			Task task = list.get(i);
			ExecuteTaskListResponse executeTaskListResponse = new ExecuteTaskListResponse();
			executeTaskListResponse.setId(task.getId());
			executeTaskListResponse.setName(task.getName());
			executeTaskListResponse.setCreateTime(DateUtil.dateToLocalDateTime(task.getCreateTime()).format(DateTimeFormatter.ofPattern(DateUtil.DEFAULT_DATETIME_PATTERN)));
			executeTaskListResponse.setPocessInstanceId(task.getProcessInstanceId());
			executeTaskListResponse.setProcessDefinitionId(task.getProcessDefinitionId());
			executeTaskListResponse.setOwner(task.getOwner());
			executeTaskListResponse.setAssignee(task.getAssignee());
			List<IdentityLink> identityLinkList = taskService.getIdentityLinksForTask(task.getId());
			if(identityLinkList!=null&&identityLinkList.size()>0){
				executeTaskListResponse.setCandidateUsers(String.join(",",identityLinkList.stream().filter(e->(e.getUserId()!=null)&&(!"".equals(e.getUserId()))).map(e->e.getUserId()).collect(Collectors.toList())));
				executeTaskListResponse.setCandidateGroups(String.join(",",identityLinkList.stream().filter(e->(e.getGroupId()!=null)&&(!"".equals(e.getGroupId()))).map(e->e.getGroupId()).collect(Collectors.toList())));
			}
			if(executeTaskListRequest.getNeedMapVariables()==true){
				Map<String,Object> variables = this.getTaskVariables(task.getId());
				executeTaskListResponse.setMap(variables);
			}
			ProcessInstance processInstance = runtimeService.createProcessInstanceQuery().processInstanceId(task.getProcessInstanceId()).singleResult();
			executeTaskListResponse.setSuspendedFlag(processInstance.isSuspended());
			executeTaskListResponseList.add(executeTaskListResponse);
		}
		return new Page(executeTaskListRequest,executeTaskListResponseList,taskQuery.count());
	}
	
	public Map<String, Object> getTaskVariables(String taskId){
		long count = taskService.createTaskQuery().taskId(taskId).count();
		if(count<=0){
			throw new RuntimeException("任务不存在");
		}
		Map<String,Object> variables = taskService.getVariables(taskId);
		return variables;
	}

	public void completeTask(String taskId,Map<String,Object> map){
		long count = taskService.createTaskQuery().taskId(taskId).count();
		if(count<=0){
			throw new RuntimeException("任务不存在");
		}
		taskService.complete(taskId,map);
	}

	public void activeOrSuspendProcessInstance(String processInstanceId,int type){
		if(type!=1&&type!=2){
			throw new RuntimeException("操作类型错误");
		}
		if(type==1){//激活
			runtimeService.activateProcessInstanceById(processInstanceId);
		}else{//挂起
			runtimeService.suspendProcessInstanceById(processInstanceId);
		}
	}

	public Page listHistoryProcessInstance(ProcessInstanceHistoryListRequest processInstanceHistoryListRequest){
		int type = processInstanceHistoryListRequest.getType();
		int firstResult = (processInstanceHistoryListRequest.getCurrentPage()-1)*processInstanceHistoryListRequest.getPageSize();
		int maxResults = processInstanceHistoryListRequest.getPageSize();
		if(type!=0&&type!=1&&type!=2){
			throw new RuntimeException("操作类型错误");
		}
		List<HistoricProcessInstance> list = null;
		HistoricProcessInstanceQuery historicProcessInstanceQuery = historyService.createHistoricProcessInstanceQuery();
		if(type==0){
			//list = historicTaskInstanceQuery.listPage(firstResult,maxResults);
		}else if(type==1){
			historicProcessInstanceQuery = historicProcessInstanceQuery.finished();
		}else if(type==2){
			historicProcessInstanceQuery = historicProcessInstanceQuery.unfinished();
		}
		list = historicProcessInstanceQuery.listPage(firstResult,maxResults);
		List<ProcessInstanceHistoryListResponse> processInstanceHistoryList = new ArrayList<>();
		for(int i=0;i<list.size();i++){
			HistoricProcessInstance historicProcessInstance = list.get(i);
			ProcessInstanceHistoryListResponse processInstanceHistoryListResponse = new ProcessInstanceHistoryListResponse();
			processInstanceHistoryListResponse.setId(historicProcessInstance.getId());
			processInstanceHistoryListResponse.setDurationInMillis(historicProcessInstance.getDurationInMillis());
			processInstanceHistoryListResponse.setProcessDefinitionId(historicProcessInstance.getProcessDefinitionId());
			processInstanceHistoryListResponse.setStartTime(historicProcessInstance.getStartTime());
			processInstanceHistoryListResponse.setEndTime(historicProcessInstance.getEndTime());
			processInstanceHistoryList.add(processInstanceHistoryListResponse);
		}
		return new Page(processInstanceHistoryListRequest,processInstanceHistoryList,historicProcessInstanceQuery.count());
	}

	public Page listHistoryTask(TaskHistoryListRequest taskHistoryListRequest){
		int type = taskHistoryListRequest.getType();
		int firstResult = (taskHistoryListRequest.getCurrentPage()-1)*taskHistoryListRequest.getPageSize();
		int maxResults = taskHistoryListRequest.getPageSize();
		if(type!=0&&type!=1&&type!=2){
			throw new RuntimeException("操作类型错误");
		}
		
		List<HistoricTaskInstance> list = null;
		HistoricTaskInstanceQuery historicTaskInstanceQuery = historyService.createHistoricTaskInstanceQuery();
		if(type==0){
			//list = historicTaskInstanceQuery.listPage(firstResult,maxResults);
		}else if(type==1){
			historicTaskInstanceQuery = historicTaskInstanceQuery.finished();
		}else if(type==2){
			historicTaskInstanceQuery = historicTaskInstanceQuery.unfinished();
		}
		list = historicTaskInstanceQuery.listPage(firstResult,maxResults);
		List<TaskHistoryListResponse> taskHistoryList = new ArrayList<>();
		for(int i=0;i<list.size();i++){
			HistoricTaskInstance historicTaskInstance = list.get(i);
			TaskHistoryListResponse taskHistoryListResponse = new TaskHistoryListResponse();
			taskHistoryListResponse.setId(historicTaskInstance.getId());
			taskHistoryListResponse.setName(historicTaskInstance.getName());
			taskHistoryListResponse.setProcessDefinitionId(historicTaskInstance.getProcessDefinitionId());
			taskHistoryListResponse.setStartTime(historicTaskInstance.getStartTime());
			taskHistoryListResponse.setEndTime(historicTaskInstance.getEndTime());
			taskHistoryList.add(taskHistoryListResponse);
		}
		return new Page(taskHistoryListRequest,taskHistoryList,historicTaskInstanceQuery.count());
	}
	
	public Page listHistoricActivityInstance(HistoricActivityInstanceListRequest historicActivityInstanceListRequest){
		String processInstanceId = historicActivityInstanceListRequest.getProcessInstanceId();
		int firstResult = (historicActivityInstanceListRequest.getCurrentPage()-1)*historicActivityInstanceListRequest.getPageSize();
		int maxResults = historicActivityInstanceListRequest.getPageSize();
		HistoricActivityInstanceQuery historicActivityInstanceQuery = historyService.createHistoricActivityInstanceQuery();
		if((processInstanceId!=null)&&(!"".equals(processInstanceId))){
			historicActivityInstanceQuery = historicActivityInstanceQuery.processInstanceId(processInstanceId);
		}
		List<HistoricActivityInstance> list = historicActivityInstanceQuery.finished().listPage(firstResult,maxResults);
		List<HistoricActivityInstanceListResponse> historicActivityInstanceList = new ArrayList<>();
		for(int i=0;i<list.size();i++){
			HistoricActivityInstance historicActivityInstance = list.get(i);
			HistoricActivityInstanceListResponse historicActivityInstanceListResponse = new HistoricActivityInstanceListResponse();
			historicActivityInstanceListResponse.setId(historicActivityInstance.getId());
			historicActivityInstanceListResponse.setTaskId(historicActivityInstance.getTaskId());
			historicActivityInstanceListResponse.setActivityId(historicActivityInstance.getActivityId());
			historicActivityInstanceListResponse.setActivityName(historicActivityInstance.getActivityName());
			historicActivityInstanceListResponse.setActivityType(historicActivityInstance.getActivityType());
			historicActivityInstanceListResponse.setStartTime(historicActivityInstance.getStartTime());
			historicActivityInstanceListResponse.setEndTime(historicActivityInstance.getEndTime());
			historicActivityInstanceListResponse.setProcessDefinitionId(historicActivityInstance.getProcessDefinitionId());
			historicActivityInstanceListResponse.setProcessDefinitionKey(historicActivityInstance.getProcessDefinitionKey());
			historicActivityInstanceList.add(historicActivityInstanceListResponse);
		}
		return new Page(historicActivityInstanceListRequest,historicActivityInstanceList,historicActivityInstanceQuery.count());
	}

	public void delegateTask(DelegateTaskRequest delegateTaskRequest){
		String taskId = delegateTaskRequest.getTaskId();
		String userId = delegateTaskRequest.getUserId();
		long count = taskService.createTaskQuery().taskId(taskId).count();
		if(count<=0){
			throw new RuntimeException("任务不存在");
		}
		taskService.delegateTask(taskId,userId);
	}

	public void finishDelegateTask(FinishDelegateTaskRequest finishDelegateTaskRequest){
		String taskId = finishDelegateTaskRequest.getTaskId();
		Map<String,Object> map = finishDelegateTaskRequest.getMap();
		long count = taskService.createTaskQuery().taskId(taskId).count();
		if(count<=0){
			throw new RuntimeException("任务不存在");
		}
		taskService.resolveTask(taskId,map);
		taskService.complete(taskId,map);
	}

	public void assigneeTask(AssigneeTaskRequest assigneeTaskRequest){
		String taskId = assigneeTaskRequest.getTaskId();
		String userId = assigneeTaskRequest.getUserId();
		long count = taskService.createTaskQuery().taskId(taskId).count();
		if(count<=0){
			throw new RuntimeException("任务不存在");
		}
		taskService.setAssignee(taskId, userId);
	}

	public List<Resource> getDeploymentResources(String deploymentId){
		long count = repositoryService.createDeploymentQuery().deploymentId(deploymentId).count();
		if(count<=0){
			throw new RuntimeException("所要获取的流程部署不存在");
		}
		List<Resource> list = repositoryService.getDeploymentResources(deploymentId);
		return list;
	}

	public void taskBack(TaskBackRequest taskBackRequest){
		//taskService.createComment(taskId,processInstanceId,message);
		String processInstanceId = taskBackRequest.getProcessInstanceId();
		String cancelActivityInstanceId = taskBackRequest.getCancelActivityInstanceId();
		String activityId = taskBackRequest.getActivityId();
		Map<String,Object> map = taskBackRequest.getMap();
		ProcessInstanceModificationBuilder processInstanceModificationBuilder = runtimeService.createProcessInstanceModification(processInstanceId).cancelActivityInstance(cancelActivityInstanceId);/*.setAnnotation("xxx")*/
		ProcessInstanceModificationInstantiationBuilder processInstanceModificationInstantiationBuilder = processInstanceModificationBuilder.startBeforeActivity(activityId);
		if(map!=null&&map.size()>0){
			processInstanceModificationInstantiationBuilder.setVariables(map);
		}
		processInstanceModificationInstantiationBuilder.execute();
	}

}