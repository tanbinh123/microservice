package com.javaweb.config.camunda;

import java.io.ByteArrayInputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.camunda.bpm.engine.repository.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.javaweb.base.BaseResponseResult;
import com.javaweb.base.BaseService;
import com.javaweb.config.camunda.service.CamundaService;
import com.javaweb.eo.camunda.ActiveOrSuspendProcessInstanceRequest;
import com.javaweb.eo.camunda.BpmnFileContentResponse;
import com.javaweb.eo.camunda.CompleteTaskRequest;
import com.javaweb.eo.camunda.DeleteDeploymentRequest;
import com.javaweb.eo.camunda.DeleteProcessDefinitionRequest;
import com.javaweb.eo.camunda.DeploymentBpmnXmlRequest;
import com.javaweb.eo.camunda.DeploymentListRequest;
import com.javaweb.eo.camunda.DeploymentListResponse;
import com.javaweb.eo.camunda.ExecuteTaskListRequest;
import com.javaweb.eo.camunda.HistoricActivityInstanceListRequest;
import com.javaweb.eo.camunda.Page;
import com.javaweb.eo.camunda.ProcessDefinitionListRequest;
import com.javaweb.eo.camunda.ProcessInstanceByIdRequest;
import com.javaweb.eo.camunda.ProcessInstanceByIdResponse;
import com.javaweb.eo.camunda.ProcessInstanceHistoryListRequest;
import com.javaweb.eo.camunda.ProcessInstanceListRequest;
import com.javaweb.eo.camunda.TaskBackRequest;
import com.javaweb.eo.camunda.TaskHistoryListRequest;
import com.javaweb.eo.camunda.TaskVariablesRequest;
import com.javaweb.util.core.FileUtil;

@RestController
@RequestMapping("/workFlow/camunda")
public class CamundaController extends BaseService {
	
	@Autowired
	private CamundaService camundaService;
	
	//部署流程图
	@PostMapping("/deploymentBpmnXmlByFile")
	public BaseResponseResult deploymentBpmnXmlByFile(HttpServletRequest httpServletRequest,
										              @RequestParam(value="resourceName",required=false) String resourceName,
										              @RequestParam(value="xmlFile",required=true) MultipartFile multipartFile[]) {
		if(multipartFile==null||multipartFile.length!=1){
			return new BaseResponseResult(605,"请上传且只能上传一张流程图");
		}
		if(resourceName==null||"".equals(resourceName.trim())){
			resourceName = "流程图_"+UUID.randomUUID().toString()+".bpmn";
		}else{
			if(!resourceName.endsWith(".bpmn")){
				return new BaseResponseResult(605,"部署流程图名称必须以.bpmn结尾");
			}
		}
		try{
			DeploymentListResponse deploymentListResponse = camundaService.deploymentBpmnXml(resourceName,multipartFile[0].getInputStream());
			return new BaseResponseResult(200,"部署流程图成功",deploymentListResponse);
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"部署流程图失败，失败原因为："+e.getMessage());
		}
	}
	
	//部署流程图
	@PostMapping("/deploymentBpmnXmlByContent")
	public BaseResponseResult deploymentBpmnXml(@RequestBody DeploymentBpmnXmlRequest deploymentBpmnXmlRequest) {
		String resourceName = deploymentBpmnXmlRequest.getResourceName();
		String xmlContent = deploymentBpmnXmlRequest.getXmlContent();
		if(xmlContent==null||"".equals(xmlContent.trim())){
			return new BaseResponseResult(605,"流程图内容不能为空");
		}
		if(resourceName==null||"".equals(resourceName.trim())){
			resourceName = "流程图_"+UUID.randomUUID().toString()+".bpmn";
		}else{
			if(!resourceName.endsWith(".bpmn")){
				return new BaseResponseResult(605,"部署流程图名称必须以.bpmn结尾");
			}
		}
		try{
			DeploymentListResponse deploymentListResponse = camundaService.deploymentBpmnXml(resourceName,xmlContent);
			return new BaseResponseResult(200,"部署流程图成功",deploymentListResponse);
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"部署流程图失败，失败原因为："+e.getMessage());
		}
	}
	
	//流程部署列表
	@PostMapping("/listDeployment")
	public BaseResponseResult listDeployment(@RequestBody DeploymentListRequest deploymentListRequest) {
		try{
			Page page = camundaService.listDeployment(deploymentListRequest);
			return new BaseResponseResult(200,"获取流程部署列表成功",page);
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"获取流程部署列表失败，失败原因为："+e.getMessage());
		}
	}
	
	//删除流程部署
	@PostMapping("/deleteDeployment")
	public BaseResponseResult deleteDeployment(@RequestBody DeleteDeploymentRequest deleteDeploymentRequest) {
		String deploymentId = deleteDeploymentRequest.getDeploymentId();
		if(deploymentId==null||"".equals(deploymentId.trim())){
			return new BaseResponseResult(605,"流程部署ID不能为空");
		}
		try{
			camundaService.deleteDeployment(deploymentId);
			return new BaseResponseResult(200,"删除流程部署成功");
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"删除流程部署失败，失败原因为："+e.getMessage());
		}
	}
	
	//流程定义列表
	@PostMapping("/listProcessDefinition")
	public BaseResponseResult listProcessDefinition(@RequestBody ProcessDefinitionListRequest processDefinitionListRequest) {
		try{
			Page page = camundaService.listProcessDefinition(processDefinitionListRequest);
			return new BaseResponseResult(200,"获取流程定义列表成功",page);
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"流程定义列表失败，失败原因为："+e.getMessage());
		}
	}
	
	//删除流程定义
	@PostMapping("/deleteProcessDefinition")
	public BaseResponseResult deleteProcessDefinition(@RequestBody DeleteProcessDefinitionRequest deleteProcessDefinitionRequest) {
		String processDefinitionId = deleteProcessDefinitionRequest.getProcessDefinitionId();
		if(processDefinitionId==null||"".equals(processDefinitionId.trim())){
			return new BaseResponseResult(605,"流程定义ID不能为空");
		}
		try{
			camundaService.deleteProcessDefinition(processDefinitionId);
			return new BaseResponseResult(200,"删除流程定义成功");
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"删除流程定义失败，失败原因为："+e.getMessage());
		}
	}
	
	//启动流程（一般用于提出流程申请）
	@PostMapping("/startProcessInstanceById")
	public BaseResponseResult startProcessInstanceById(@RequestBody ProcessInstanceByIdRequest processInstanceByIdRequest) {
		try{
			if(processInstanceByIdRequest.getMap()==null){
				processInstanceByIdRequest.setMap(new HashMap<>());
			}
			ProcessInstanceByIdResponse processInstanceByIdResponse = camundaService.startProcessInstanceById(processInstanceByIdRequest.getProcessDefinitionId(),processInstanceByIdRequest.getBusinessKey(),processInstanceByIdRequest.getMap());
			return new BaseResponseResult(200,"启动流程成功",processInstanceByIdResponse);
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"启动流程失败，失败原因为："+e.getMessage());
		}
	}
	
	//获取流程实例列表
	@PostMapping("/listProcessInstance")
	public BaseResponseResult listProcessInstance(@RequestBody ProcessInstanceListRequest processInstanceListRequest) {
		try{
			return new BaseResponseResult(200,"获取流程实例列表成功",camundaService.listProcessInstance(processInstanceListRequest));
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"获取流程实例列表失败，失败原因为："+e.getMessage());
		}
	}
	
	//获取任务列表
	@PostMapping("/listTask")
	public BaseResponseResult listTask(@RequestBody ExecuteTaskListRequest executeTaskListRequest) {
		try{
			Page page = camundaService.listExecuteTask(executeTaskListRequest);
			return new BaseResponseResult(200,"获取任务列表成功",page);
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"获取任务列表失败，失败原因为："+e.getMessage());
		}
	}
	
	//获取任务对应的参数
	@PostMapping("/getTaskVariables")
	public BaseResponseResult getTaskVariables(@RequestBody TaskVariablesRequest taskVariablesRequest) {
		try{
			Map<String,Object> map = camundaService.getTaskVariables(taskVariablesRequest.getTaskId());
			return new BaseResponseResult(200,"获取任务对应的参数成功",map);
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"获取任务对应的参数失败，失败原因为："+e.getMessage());
		}
	}
	
	//完成任务
	@PostMapping("/completeTask")
	public BaseResponseResult completeTask(@RequestBody CompleteTaskRequest completeTaskRequest) {
		try{
			camundaService.completeTask(completeTaskRequest.getTaskId(),completeTaskRequest.getMap());
			return new BaseResponseResult(200,"完成任务成功");
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"完成任务失败，失败原因为："+e.getMessage());
		}
	}
	
	//激活/挂起流程实例
	@PostMapping("/activeOrSuspendProcessInstance")
	public BaseResponseResult activeOrSuspendProcessInstance(@RequestBody ActiveOrSuspendProcessInstanceRequest activeOrSuspendProcessInstanceRequest) {
		try{
			camundaService.activeOrSuspendProcessInstance(activeOrSuspendProcessInstanceRequest.getProcessInstanceId(),activeOrSuspendProcessInstanceRequest.getType());
			return new BaseResponseResult(200,(activeOrSuspendProcessInstanceRequest.getType()==1?"激活":"挂起")+"流程实例成功");
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,(activeOrSuspendProcessInstanceRequest.getType()==1?"激活":"挂起")+"流程实例失败"+"，失败原因为："+e.getMessage());
		}
	}
	
	//获取历史流程实例列表
	@PostMapping("/listHistoryProcessInstance")
	public BaseResponseResult listHistoryProcessInstance(@RequestBody ProcessInstanceHistoryListRequest processInstanceHistoryListRequest) {
		try{
			return new BaseResponseResult(200,"获取历史流程实例列表成功",camundaService.listHistoryProcessInstance(processInstanceHistoryListRequest));
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"获取历史流程实例列表失败，失败原因为："+e.getMessage());
		}
	}
	
	//获取历史任务列表
	@PostMapping("/listHistoryTask")
	public BaseResponseResult listHistoryTask(@RequestBody TaskHistoryListRequest taskHistoryListRequest) {
		try{
			return new BaseResponseResult(200,"获取历史任务列表成功",camundaService.listHistoryTask(taskHistoryListRequest));
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"获取历史任务列表失败，失败原因为："+e.getMessage());
		}
	}
	
	//历史激活实例信息列表
	@PostMapping("/listHistoricActivityInstance")
	public BaseResponseResult listHistoricActivityInstance(@RequestBody HistoricActivityInstanceListRequest historicActivityInstanceListRequest) {
		try{
			return new BaseResponseResult(200,"获取历史激活实例信息列表成功",camundaService.listHistoricActivityInstance(historicActivityInstanceListRequest));
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"获取历史激活实例信息列表失败，失败原因为："+e.getMessage());
		}
	}
	
	//获取流程部署资源（一般为bpmn文件）
	@GetMapping("/getBpmnFileInputStream/{deploymentId}")
	public void getBpmnFileInputStream(HttpServletRequest request,HttpServletResponse response,@PathVariable(name="deploymentId",required=true) String deploymentId) {
		try{
			Resource resource = camundaService.getDeploymentResources(deploymentId).get(0);
			byte bpmnBytes[] = resource.getBytes();
			String name = resource.getName();
			response.setHeader("Cache-Control","no-store,no-cache");
			response.setHeader("Content-Disposition","attachment;filename="+URLEncoder.encode(name,"UTF-8"));
			FileUtil.downloadFile(response.getOutputStream(),new byte[1024],new ByteArrayInputStream(bpmnBytes));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	//获取流程部署资源（一般为bpmn文件）
	@GetMapping("/getBpmnFileContentResponse/{deploymentId}")
	public BaseResponseResult getBpmnFileContentResponse(HttpServletRequest request,HttpServletResponse response,@PathVariable(name="deploymentId",required=true) String deploymentId) {
		try{
			Resource resource = camundaService.getDeploymentResources(deploymentId).get(0);
			byte bpmnBytes[] = resource.getBytes();
			String name = resource.getName();
			BpmnFileContentResponse bpmnFileContentResponse = new BpmnFileContentResponse();
			bpmnFileContentResponse.setFileName(name);
			bpmnFileContentResponse.setFileContent(new String(bpmnBytes,"UTF-8"));
			return new BaseResponseResult(200,"获取流程部署资源（一般为bpmn文件）成功",bpmnFileContentResponse);
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"获取流程部署资源（一般为bpmn文件）失败，失败原因为："+e.getMessage());
		}
	}
	
	//任务回退
	@PostMapping("/taskBack")
	public BaseResponseResult taskBack(@RequestBody TaskBackRequest taskBackRequest){
		try{
			camundaService.taskBack(taskBackRequest);
			return new BaseResponseResult(200,"任务回退成功");
		}catch(Exception e){
			e.printStackTrace();
			return new BaseResponseResult(605,"任务回退失败，失败原因为："+e.getMessage());
		}
	}
	
}
