package com.javaweb.config.desensitization;

/** 客户隐私信息
身份证号、军官证、护照
驾驶证
社保卡号、银行帐号
出生日期、年龄、性别
手机号
单位电话、工作单位、工作地址
家庭联系电话、家庭地址
学历、职业
征信信息、交易信息
电子邮箱
生物识别信息
*/
public enum DesensitizationTypeEnum {
	
	NAME,//姓名

	ID_CARD,//身份证号码
	
	CERTIFICATE_OFFICERS,//军官证
	
	PASSPORT,//护照

	DRIVER_LICENSE,//驾驶证
	
	SOCIAL_SECURITY_NO,//社保卡号
	
	BANK_NO,//银行账号
	
	BIRTHDAY,//出生日期

	AGE,//年龄

	SEX,//性别
	
	PHONE,//手机号
	
	UNIT_PHONE,//单位电话
	
	WORK_UNIT,//工作单位
	
	WORK_ADDRESS,//工作地址
	
	HOME_PHONE,//家庭联系电话
	
	HOME_ADDRESS,//家庭地址
	
	EDUCATION_BACKGROUND,//学历
	
	PROFESSION,//职业
	
	CREDIT_INFO,//征信信息
	
	TRADE_INFO,//交易信息
	
	EMAIL//电子邮箱
	
}
