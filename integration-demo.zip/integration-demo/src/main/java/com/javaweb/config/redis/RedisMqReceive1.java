package com.javaweb.config.redis;

import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.stereotype.Component;

@Component
public class RedisMqReceive1 implements MessageListener {
	
	/**
	public void receiveMessage(String message) {
	    System.out.println("接收到的消息为："+message);
	}
	*/

	public void onMessage(Message message,byte[] byteArray) {
		System.out.println("接收到的消息体为："+new String(message.getBody()));
        System.out.println("接收到的频道名为："+new String(message.getChannel()));
	}

}
