package com.javaweb.config.webservice;

import javax.xml.namespace.QName;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;

public class WebServiceHandle {
	
	//调用示例：webServiceRequest("http://127.0.0.1:8080/a/b/c?wsdl","http://127.0.0.1:8080/a/b/c/","method1",new Object[]{"a","b","c",new User()})
	public static Object[] webServiceRequest(String wsdlUrl,String namespaceUrl,String localPart,Object request[]) throws Exception {
		JaxWsDynamicClientFactory factory = JaxWsDynamicClientFactory.newInstance();
		Client client = factory.createClient(wsdlUrl/*"http://10.187.29.99:8002/smsInfo/smsReceive?wsdl"*/);
	    /**
		client.getOutInterceptors().add(new ClientLoginInterceptor(USER_NAME,PASS_WORD));
		HTTPConduit conduit = (HTTPConduit) client.getConduit();
	    HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
	    httpClientPolicy.setConnectionTimeout(3000);//连接超时
	    httpClientPolicy.setAllowChunking(false);//取消块编码
	    httpClientPolicy.setReceiveTimeout(10000);//响应超时
	    conduit.setClient(httpClientPolicy);
	    */
		QName qName = new QName(namespaceUrl,localPart);
		Object[] response = client.invoke(qName,request);
		return response;
	}
	
	//调用示例：webServiceRequest("http://127.0.0.1:8080/c/d/e?wsdl","method2",new Object[]{"a","b","c",new User()})
	public static Object[] webServiceRequest(String wsdlUrl,String localPart,Object request[]) throws Exception {
		JaxWsDynamicClientFactory factory = JaxWsDynamicClientFactory.newInstance();
		Client client = factory.createClient(wsdlUrl);
	    /**
		client.getOutInterceptors().add(new ClientLoginInterceptor(USER_NAME,PASS_WORD));
		HTTPConduit conduit = (HTTPConduit) client.getConduit();
	    HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
	    httpClientPolicy.setConnectionTimeout(3000);//连接超时
	    httpClientPolicy.setAllowChunking(false);//取消块编码
	    httpClientPolicy.setReceiveTimeout(10000);//响应超时
	    conduit.setClient(httpClientPolicy);
	    */
		Object[] response = client.invoke(localPart,request);
		return response;
	}

}
