package com.javaweb.config.validate;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.javaweb.base.BaseValidatedGroup.add;
import com.javaweb.base.BaseValidatedGroup.update;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class User implements Serializable {
	
	private static final long serialVersionUID = -4238003574744110907L;

	@NotEmpty(groups={update.class},message="validated.user.userId.notEmpty")
	private String userId;//用户ID

	@NotEmpty(groups={add.class,update.class},message="validated.user.userName.notNull")
	@Pattern(groups={add.class,update.class},regexp="^(?![^a-zA-Z]+$)(?!\\D+$).{6,20}$",message="validated.user.userName.pattern")
	private String userName;//用户名
	
	@NotEmpty(groups={add.class},message="validated.user.password.notNull")
	@Pattern(groups={add.class},regexp="^(?![^a-zA-Z]+$)(?!\\D+$).{6,20}$",message="validated.user.password.pattern")
	private String password;//用户密码
	
	@NotEmpty(groups={add.class,update.class},message="validated.user.personName.notNull")
	@Size(groups={add.class,update.class},max=20,message="validated.user.personName.maxLength.limit")
	private String personName;//用户姓名
	
	@Size(groups={add.class,update.class},max=20,message="validated.user.idCard.maxLength.limit")
	private String idCard;//身份证号码

	@Size(groups={add.class,update.class},max=50,message="validated.user.email.maxLength.limit")
	private String email;//电子邮箱
	
	@Size(groups={add.class,update.class},max=20,message="validated.user.phone.maxLength.limit")
	private String phone;//手机号码
	
	private String portrait;//头像
	
	private String parentId;//创建该用户的ID
	
	private String fcode;//层级关系
	
	private Integer level;//第几级（层级数0为最高，即根节点）
	
	@Size(groups={add.class,update.class},max=100,message="validated.user.remark.maxLength.limit")
	private String remark;//备注
	
}
