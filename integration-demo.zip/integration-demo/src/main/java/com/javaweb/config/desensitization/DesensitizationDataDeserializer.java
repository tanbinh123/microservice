package com.javaweb.config.desensitization;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

public class DesensitizationDataDeserializer extends StdDeserializer<String> {

	private static final long serialVersionUID = 8347373728988337296L;
	
	private DesensitizationAnnotation desensitizationAnnotation;

	public DesensitizationDataDeserializer() {
        super(String.class);
    }
	
	public DesensitizationDataDeserializer(DesensitizationAnnotation desensitizationAnnotation) {
		super(String.class);
		this.desensitizationAnnotation = desensitizationAnnotation;
    }
	
	public DesensitizationAnnotation getDesensitizationAnnotation() {
		return desensitizationAnnotation;
	}

	public void setDesensitizationAnnotation(DesensitizationAnnotation desensitizationAnnotation) {
		this.desensitizationAnnotation = desensitizationAnnotation;
	}

	public String deserialize(JsonParser jsonParser,DeserializationContext deserializationContext) throws IOException,JsonProcessingException {
        return jsonParser.getValueAsString();
    }
	
}
