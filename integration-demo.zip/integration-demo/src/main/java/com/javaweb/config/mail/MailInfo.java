package com.javaweb.config.mail;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MailInfo {

    public static String mailReceiveProtocol;//邮件接收协议

    public static String mailReceivePort;//邮件接收端口

    public static String mailReceiveHost;//邮件接收域名
    
    public static String mailSendProtocol;//邮件发送协议

    public static String mailSendPort;//邮件发送端口

    public static String mailSendHost;//邮件发送域名
    
    public static String mailSaveUrl;//邮件保存路径

    @Value("${mail.receive.protocol}")
    public  void setMailReceiveProtocol(String mailReceiveProtocol) {
        MailInfo.mailReceiveProtocol = mailReceiveProtocol;
    }

    @Value("${mail.receive.port}")
    public  void setMailReceivePort(String mailReceivePort) {
        MailInfo.mailReceivePort = mailReceivePort;
    }

    @Value("${mail.receive.host}")
    public  void setMailReceiveHost(String mailReceiveHost) {
        MailInfo.mailReceiveHost = mailReceiveHost;
    }

    @Value("${mail.send.protocol}")
    public  void setMailSendProtocol(String mailSendProtocol) {
        MailInfo.mailSendProtocol = mailSendProtocol;
    }

    @Value("${mail.send.port}")
    public void setMailSendPort(String mailSendPort) {
        MailInfo.mailSendPort = mailSendPort;
    }

    @Value("${mail.send.host}")
    public void setMailSendHost(String mailSendHost) {
        MailInfo.mailSendHost = mailSendHost;
    }

    @Value("${mail.save.url}")
    public void setMailSaveUrl(String mailSaveUrl) {
        MailInfo.mailSaveUrl = mailSaveUrl;
    }
    
}
