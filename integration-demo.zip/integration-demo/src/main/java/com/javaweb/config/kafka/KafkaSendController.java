package com.javaweb.config.kafka;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class KafkaSendController {

	@Autowired
    private KafkaTemplate<String, String> kafkaTemplate;
	
	@GetMapping("send")
	public String send() throws Exception {
		//ListenableFuture<SendResult<String,String>> listenableFuture = this.kafkaTemplate.send("Topic","Key",String.valueOf(Math.random()));
		ProducerRecord<String,String> producerRecord = new ProducerRecord<String, String>("Topic","Key",String.valueOf(Math.random()));
		ListenableFuture<SendResult<String,String>> listenableFuture = this.kafkaTemplate.send(producerRecord);
		SendResult<String,String> sendResult = listenableFuture.get();
		RecordMetadata recordMetadata = sendResult.getRecordMetadata();
		return recordMetadata.offset()+","+recordMetadata.partition();
	}
	
}
