package com.javaweb.config.transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;

//在需要手动提交或回滚的类里进行处理
public class TransactionController {
	
	@Autowired
	protected DataSourceTransactionManager dataSourceTransactionManager;
	
	@Autowired
	protected TransactionDefinition transactionDefinition;
	
	//手动提交或回滚事务
	public void manuallyCommitAndRollBackTransaction(){
		TransactionStatus transactionStatus = dataSourceTransactionManager.getTransaction(transactionDefinition);
		dataSourceTransactionManager.commit(transactionStatus);//手动提交事务
		dataSourceTransactionManager.rollback(transactionStatus);//手动回滚事务
	}

}
