package com.javaweb.config.mail;

import java.io.File;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;

import com.javaweb.util.core.FileUtil;
import com.javaweb.util.core.SystemUtil;
import com.sun.mail.pop3.POP3Store;

/**
 * 参考：
 * https://www.cnblogs.com/shihaiming/p/10416383.html
 * https://www.cnblogs.com/sunhaoyu/p/6480117.html
 */
public class MaiReceivelUtil {
	
	/**
	//读取pdf简单示例
	//<dependency>
	//    <groupId>org.apache.pdfbox</groupId>
	//    <artifactId>pdfbox</artifactId>
	//    <version>2.0.23</version>
	//</dependency>
	public static void main(String[] args) throws Exception {
		PDFParser parser = new PDFParser(new RandomAccessFile(new File("D:\\桌面\\ASUZEXE132115873274.pdf"),"r"));
		parser.parse();
		PDDocument pdfdocument = parser.getPDDocument();
		PDFTextStripper stripper = new PDFTextStripper();
		stripper.setSortByPosition(true);
		stripper.setStartPage(1);
		stripper.setEndPage(1);
		String result = stripper.getText(pdfdocument);
		String each[] = result.split("\\n");
		for(String e:each){
			if(e!=null&&e.contains("投保人名称")){
				System.out.println(e.substring(e.indexOf("：")+1,e.length()));
			}
		}
		pdfdocument.close();
	}
	*/
	
	public static final String FILE_SEPARATE_PATH = (SystemUtil.isLinux()==true?"/":"\\");
	
	//接收消息
    public static void receiveMessage(String userName, String password) throws Exception {
        Properties properties = new Properties();
        properties.setProperty("mail.store.protocol", MailInfo.mailReceiveProtocol);
        properties.setProperty("mail." + MailInfo.mailReceiveProtocol + ".host", MailInfo.mailReceiveHost);
        properties.setProperty("mail." + MailInfo.mailReceiveProtocol + ".port", MailInfo.mailReceivePort);
        properties.setProperty("mail." + MailInfo.mailReceiveProtocol + ".auth", "true");
        //properties.setProperty("mail."+protocol+".ssl.starttls.enable","true");
        //properties.setProperty("mail.debug","true");
        Session session = Session.getDefaultInstance(properties);
        POP3Store store = (POP3Store) session.getStore(MailInfo.mailReceiveProtocol);//Store store = session.getStore(protocol);
        store.connect(userName, password);
        Folder folder = store.getFolder("INBOX");
        folder.open(Folder.READ_WRITE);
        //打印不同状态的邮件数量
        System.out.println("收件箱中共" + folder.getMessageCount() + "封邮件!");
        //System.out.println("收件箱中共" + folder.getUnreadMessageCount() + "封未读邮件!");
        //System.out.println("收件箱中共" + folder.getNewMessageCount() + "封新邮件!");
        //System.out.println("收件箱中共" + folder.getDeletedMessageCount() + "封已删除邮件!");
        int total = folder.getMessageCount();
        Message[] message = folder.getMessages();
        for (int i = 0; i < total; i++) {
            MimeMessage getMessage = (MimeMessage) message[i];
            System.out.println("主题: " + getSubject(getMessage));
            System.out.println("发件人: " + getFrom(getMessage));
            System.out.println("收件人：" + getReceive(getMessage, null));
            System.out.println("发送时间：" + getSentDate(getMessage, null));
            System.out.println("是否已读：" + isSeen(getMessage));
            System.out.println("邮件优先级：" + getPriority(getMessage));
            System.out.println("是否需要回执：" + isReplySign(getMessage));
            System.out.println("邮件大小：" + getMessage.getSize() / 1024 + "kb");
            System.out.println("是否包含附件：" + isContainAttachment(getMessage));
            if (isContainAttachment(getMessage)) {
                String format = new SimpleDateFormat("yyyyMMdd").format(new Date());
                int year = Integer.parseInt(format.substring(0,4));
                int month = Integer.parseInt(format.substring(4,6));
                int day = Integer.parseInt(format.substring(6,8));
                String filePath = MailInfo.mailSaveUrl + FILE_SEPARATE_PATH + year + FILE_SEPARATE_PATH + month + FILE_SEPARATE_PATH + day;
                File file = new File(filePath);
                if (!file.isDirectory()) {
                    file.mkdirs();
                }
                saveAttachment(getMessage,filePath);
            }
            StringBuffer content = new StringBuffer();
            getMailTextContent(getMessage, content);
            System.out.println("文件内容：" + content);
            System.out.println("MessageID：" + getMessage.getMessageID());
            //1、POP3：由于POP3协议是不支持该功能的，POP3只支持Flags.Flag.DELETE，POP3没有状态，只能读出和删除，如果想标志邮件的状态，只能在本地如数据库中标出每封邮件的状态，读的时候进行比较。用Message-ID做主键
            //2、IMAP：如果是IMAP协议可以通过message.setFlag(Flags.Flag.SEEN,true)来标识邮件为已读
            getMessage.setFlag(Flags.Flag.DELETED, true);//删除邮件（这里业务处理为：读过的删除，反正可以在废纸篓中查看到）
        }
        folder.close(true);
        store.close();
    }

    public static String getSubject(MimeMessage msg) throws Exception {
        return MimeUtility.decodeText(msg.getSubject());
    }

    public static String getFrom(MimeMessage msg) throws Exception {
        String from = "";
        Address[] froms = msg.getFrom();
        if (froms.length < 1) {
            throw new MessagingException("没有发件人!");
        }
        InternetAddress address = (InternetAddress) froms[0];
        String person = address.getPersonal();
        if (person != null) {
            person = MimeUtility.decodeText(person) + " ";
        } else {
            person = "";
        }
        from = person + "<" + address.getAddress() + ">";
        return from;
    }

    public static String getReceive(MimeMessage msg, Message.RecipientType type) throws Exception {
        StringBuffer receiveAddress = new StringBuffer();
        Address[] addresss = null;
        if (type == null) {
            addresss = msg.getAllRecipients();
        } else {
            addresss = msg.getRecipients(type);
        }
        if (addresss == null || addresss.length < 1) {
            throw new MessagingException("没有收件人!");
        }
        for (Address address : addresss) {
            InternetAddress internetAddress = (InternetAddress) address;
            receiveAddress.append(internetAddress.toUnicodeString()).append(",");
        }
        receiveAddress.deleteCharAt(receiveAddress.length() - 1);//删除最后一个逗号
        return receiveAddress.toString();
    }

    public static String getSentDate(MimeMessage msg, String pattern) throws Exception {
        Date receivedDate = msg.getSentDate();
        if (receivedDate == null) {
            return "";
        }
        if (pattern == null || "".equals(pattern)) {
            pattern = "yyyy-MM-dd HH:mm:ss";
        }
        return new SimpleDateFormat(pattern).format(receivedDate);
    }

    public static boolean isSeen(MimeMessage msg) throws Exception {
        return msg.getFlags().contains(Flags.Flag.SEEN);
    }

    public static String getPriority(MimeMessage msg) throws Exception {
        String priority = "普通";
        String[] headers = msg.getHeader("X-Priority");
        if (headers != null) {
            String headerPriority = headers[0];
            if (headerPriority.indexOf("1") != -1 || headerPriority.indexOf("High") != -1) {
                priority = "紧急";
            } else if (headerPriority.indexOf("5") != -1 || headerPriority.indexOf("Low") != -1) {
                priority = "低";
            } else {
                priority = "普通";
            }
        }
        return priority;
    }

    public static boolean isReplySign(MimeMessage msg) throws Exception {
        boolean replySign = false;
        String[] headers = msg.getHeader("Disposition-Notification-To");
        if (headers != null) {
            replySign = true;
        }
        return replySign;
    }

    public static boolean isContainAttachment(Part part) throws Exception {
        boolean flag = false;
        if (part.isMimeType("multipart/*")) {
            MimeMultipart multipart = (MimeMultipart) part.getContent();
            int partCount = multipart.getCount();
            for (int i = 0; i < partCount; i++) {
                BodyPart bodyPart = multipart.getBodyPart(i);
                String disp = bodyPart.getDisposition();
                if (disp != null && (disp.equalsIgnoreCase(Part.ATTACHMENT) || disp.equalsIgnoreCase(Part.INLINE))) {
                    flag = true;
                } else if (bodyPart.isMimeType("multipart/*")) {
                    flag = isContainAttachment(bodyPart);
                } else {
                    String contentType = bodyPart.getContentType();
                    if (contentType.indexOf("application") != -1) {
                        flag = true;
                    }

                    if (contentType.indexOf("name") != -1) {
                        flag = true;
                    }
                }
                if (flag) {
                    break;
                }
            }
        } else if (part.isMimeType("message/rfc822")) {
            flag = isContainAttachment((Part) part.getContent());
        }
        return flag;
    }

    public static void getMailTextContent(Part part, StringBuffer content) throws Exception {
        //如果是文本类型的附件，通过getContent方法可以取到文本内容，但这不是我们需要的结果，所以在这里要做判断  
        boolean isContainTextAttach = part.getContentType().indexOf("name") > 0;
        if (part.isMimeType("text/*") && !isContainTextAttach) {
            content.append(part.getContent().toString());
        } else if (part.isMimeType("message/rfc822")) {
            getMailTextContent((Part) part.getContent(), content);
        } else if (part.isMimeType("multipart/*")) {
            Multipart multipart = (Multipart) part.getContent();
            int partCount = multipart.getCount();
            for (int i = 0; i < partCount; i++) {
                BodyPart bodyPart = multipart.getBodyPart(i);
                getMailTextContent(bodyPart, content);
            }
        }
    }

    public static void saveAttachment(Part part, String filePath) throws Exception {
        if (part.isMimeType("multipart/*")) {
            Multipart multipart = (Multipart) part.getContent();//复杂体邮件
            //复杂体邮件包含多个邮件体
            int partCount = multipart.getCount();
            for (int i = 0; i < partCount; i++) {
                //获得复杂体邮件中其中一个邮件体
                BodyPart bodyPart = multipart.getBodyPart(i);
                //某一个邮件体也有可能是由多个邮件体组成的复杂体
                String disp = bodyPart.getDisposition();
                if (disp != null && (disp.equalsIgnoreCase(Part.ATTACHMENT) || disp.equalsIgnoreCase(Part.INLINE))) {
                    InputStream is = bodyPart.getInputStream();
                    FileUtil.writeFile(is, new byte[1024], new File(filePath + decodeText(bodyPart.getFileName())));
                } else if (bodyPart.isMimeType("multipart/*")) {
                    saveAttachment(bodyPart, filePath);
                } else {
                    String contentType = bodyPart.getContentType();
                    if (contentType.indexOf("name") != -1 || contentType.indexOf("application") != -1) {
                        FileUtil.writeFile(bodyPart.getInputStream(), new byte[1024], new File(filePath + decodeText(bodyPart.getFileName())));
                    }
                }
            }
        } else if (part.isMimeType("message/rfc822")) {
            saveAttachment((Part) part.getContent(), filePath);
        }
    }

    public static String decodeText(String encodeText) throws Exception {
        if(encodeText==null||"".equals(encodeText)){
            return "";
        }else{
            //return MimeUtility.decodeText(encodeText);
        	return decodeMailString(encodeText);
        }
    }
    
    //将GB2312转为UTF-8
    public static String decodeMailString(String str) {
    	try {
    		if(str == null){
    			return null;
    		}
    		StringBuilder sb = new StringBuilder();
    		String[] aStr;
    		while(true){
    			int pos = str.indexOf("=?");
    			if ( pos > -1) {
    				str = MimeUtility.decodeText(str);
    				aStr = str.split("=\\?",2);
    				sb.append(aStr[0]);
    				if(aStr.length>1){
    					str = "=?" + aStr[1];
    				}else{
    					return sb.toString();
    				}
    			}else{
    				return str;
    			}
    		}
    	} catch (UnsupportedEncodingException e) {
    		e.printStackTrace();
    	}
    	return null;
    }
    
}
