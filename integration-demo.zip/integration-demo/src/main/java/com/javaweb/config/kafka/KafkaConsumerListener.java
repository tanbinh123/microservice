package com.javaweb.config.kafka;

import java.util.List;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Component
public class KafkaConsumerListener {
	
	@KafkaListener(groupId="x",topics="a")
	public void listen_A(ConsumerRecord<String,String> record) {
		System.out.println("得到数据:"+record.value());
	}
	
	@KafkaListener(topics={"b"})
	public void listen_B(ConsumerRecord<?,?> record) {
		
	}

	@KafkaListener(topics={"c1","c2","c3"})
    public void listen_C(ConsumerRecord<String,String> record) {
        
    }
	
	@KafkaListener(topics={"d"})
	public void listen_D(String message) {
		
	}
	
	@KafkaListener(topics={"e"},groupId="y",containerFactory="kafkaListenerContainerFactory")
	public void kafkaListener(List<ConsumerRecord<String,String>> records,Acknowledgment ack){
		records.stream().forEach(e->System.out.println(e.value()));
		ack.acknowledge();
	}

}
