package com.javaweb.config.desensitization;

@FunctionalInterface
public interface DesensitizationHandler {

	public String handleData(String obj);
	
}
