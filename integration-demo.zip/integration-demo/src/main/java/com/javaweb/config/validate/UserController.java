package com.javaweb.config.validate;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javaweb.annotation.url.ControllerMethod;
import com.javaweb.base.BaseValidatedGroup;

@RestController
@RequestMapping("/web/user")
public class UserController {

	//普遍有两种写法，参考：GlobalExceptionHandler->handleMethodArgumentNotValidException
	@PostMapping("add")
	@ControllerMethod(interfaceName="新增用户接口")
	public String add(@RequestBody @Validated({BaseValidatedGroup.add.class}) User user){
		return "success";
	}
	
	//普遍有两种写法，参考：GlobalExceptionHandler->handleMethodArgumentNotValidException
	@PostMapping("modify")
	@ControllerMethod(interfaceName="修改用户接口")
	public String modify(@RequestBody @Validated({BaseValidatedGroup.update.class}) User user){
		return "success";
	}

}
