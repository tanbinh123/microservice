package com.javaweb.config.camunda;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.camunda.bpm.engine.task.IdentityLink;
import org.camunda.bpm.engine.task.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javaweb.base.BaseResponseResult;
import com.javaweb.base.BaseService;
import com.javaweb.config.camunda.service.CamundaService;
import com.javaweb.eo.camunda.ProcessInstanceByIdResponse;

@RestController
public class DemoController extends BaseService {
	
	@Autowired
	private CamundaService camundaService;

	@GetMapping("/init")
	public String init() throws Exception{
		System.out.println(runtimeService);
		System.out.println(taskService);
		System.out.println(repositoryService);
		System.out.println(historyService);
		System.out.println(identityService);
		return "success";
	}
	
	@GetMapping("/test")
	public BaseResponseResult test() throws Exception{
		return new BaseResponseResult(200,"OK");
	}
	
	//提出出差申请
	@GetMapping("/startProcess")
	public ProcessInstanceByIdResponse startProcess() throws Exception {
		Map<String,Object> map = new HashMap<>();//其它参数
        List<String> list = new ArrayList<>();
        list.add("张三");
        list.add("李四");
        map.put("signUserList",list);
		String businessKey = "BUSINESS_KEY_"+new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());//业务key
		ProcessInstanceByIdResponse processInstanceByIdResponse = camundaService.startProcessInstanceById("aaaaaaa:2:4d1ad7b9-b3b1-11eb-9834-509a4c33f08d",businessKey,map);
		return processInstanceByIdResponse;
	}
	
	//人员对应部门负责人审核——审核同意且出差天数大于1天
	@GetMapping("/case1")
	public String case1() {
		//Task task = taskService.createTaskQuery().taskId("756cb7e6-b202-11eb-9120-509a4c33f08d").singleResult();//任务实例ID
		Task task = taskService.createTaskQuery().taskName("人员对应部门负责人审核").singleResult();
		if(task==null){
			return "fail";
		}else{
			//Map<String,Object> vars = taskService.getVariables(task.getId());
			//System.out.println(vars);//拿到vars里的map
			List<IdentityLink> list = taskService.getIdentityLinksForTask(task.getId());
			list.stream().forEach(e->{
				System.out.println(e.getGroupId());//拿到分组信息，如【本部门,部门经理】
			});
			Map<String,Object> variables = new HashMap<>();
            variables.put("approve",true);//同意
            variables.put("day",3);//请假3天
            taskService.complete(task.getId(),variables);
			return "success";
		}
	}
	
	//公司副总经理审核——审核同意（不需要会签）
	@GetMapping("/case2")
	public String case2() {
		//Task task = taskService.createTaskQuery().taskId("1894703d-b1ff-11eb-aa38-509a4c33f08d").singleResult();//任务实例ID
		List<Task> tasks = taskService.createTaskQuery().taskName("公司副总经理审核").list();
		if(tasks==null||tasks.size()==0){
			return "fail";
		}else{
			//Map<String,Object> vars = taskService.getVariables(task.getId());
			//System.out.println(vars);//拿到vars里的map
			for(int i=0;i<tasks.size();i++){
				Task task = tasks.get(i);
				System.out.println("ID:"+task.getId()+",NAME:"+task.getName());
				List<IdentityLink> list = taskService.getIdentityLinksForTask(task.getId());
				list.stream().forEach(e->{
					System.out.println(e.getGroupId());//拿到分组信息，如【本部门,部门经理】
				});
				
				Map<String,Object> vars = taskService.getVariables(task.getId());
				System.out.println(vars);//拿到vars里的map
				if(vars.get("signFinish")==null){//表示没有会签操作
					Map<String,Object> variables = new HashMap<>();
					variables.put("approve",true);//同意
					variables.put("sign",false);//不需要会签
					taskService.complete(task.getId(),variables);
				}else{
					if(Boolean.parseBoolean(vars.get("signFinish").toString())==true){
						Map<String,Object> variables = new HashMap<>();
						variables.put("approve",true);//同意
						variables.put("sign",false);//不需要会签
						taskService.complete(task.getId(),variables);
					}
				}
			}
			return "success";
		}
	}
	
	//公司副总经理审核——审核同意（需要会签）
	@GetMapping("/case3")
	public String case3() {
		//Task task = taskService.createTaskQuery().taskId("1894703d-b1ff-11eb-aa38-509a4c33f08d").singleResult();//任务实例ID
		List<Task> tasks = taskService.createTaskQuery().taskName("公司副总经理审核").list();
		if(tasks==null||tasks.size()==0){
			return "fail";
		}else{
			//Map<String,Object> vars = taskService.getVariables(task.getId());
			//System.out.println(vars);//拿到vars里的map
			for(int i=0;i<tasks.size();i++){
				Task task = tasks.get(i);
				System.out.println("ID:"+task.getId()+",NAME:"+task.getName());
				List<IdentityLink> list = taskService.getIdentityLinksForTask(task.getId());
				list.stream().forEach(e->{
					System.out.println(e.getGroupId());//拿到分组信息，如【本部门,部门经理】
				});
				Map<String,Object> vars = taskService.getVariables(task.getId());
				System.out.println(vars);//拿到vars里的map
				if(vars.get("signFinish")==null){//表示没有会签操作
					Map<String,Object> variables = new HashMap<>();
					variables.put("sign",true);//需要会签
					List<String> signList = new ArrayList<>();
					signList.add("张三");signList.add("李四");
					variables.put("signList",signList);
					taskService.complete(task.getId(),variables);
				}
			}
			return "success";
		}
	}
	
	/** 会签：nrOfInstance（实例的数目）、nrOfCompletedInstances（完成实例的数目）、nrOfActiveInstance（未完成实例的数目） */
	//并行会签任务（需要执行两次并注意signFinish值的调整）
	@GetMapping("/case4")
	public String case4() {
		//Task task = taskService.createTaskQuery().taskId("1894703d-b1ff-11eb-aa38-509a4c33f08d").singleResult();//任务实例ID
		List<Task> tasks = taskService.createTaskQuery().taskName("并行会签任务").list();
		if(tasks==null||tasks.size()==0){
			return "fail";
		}else{
			Task task = tasks.get(0);
			Map<String,Object> vars = taskService.getVariables(task.getId());
			System.out.println(vars);//拿到vars里的map
			/** 第一次设值 start */
			//Map<String,Object> variables = new HashMap<>();
			//List<String> signList = new ArrayList<>();
			//signList.add("李四");
			//variables.put("signList",signList);
			//variables.put("signFinish",false);
			//variables.put("nrOfActiveInstance",Integer.parseInt(vars.get("nrOfActiveInstances").toString()));
			//taskService.complete(task.getId(),variables);
			/** 第一次设值 end */
			
			/** 第二次设值 start */
			//Map<String,Object> variables = new HashMap<>();
			//List<String> signList = new ArrayList<>();
			//signList.add("张三");
			//variables.put("signList",signList);
			//variables.put("signFinish",true);
			//variables.put("nrOfActiveInstance",0);
			//taskService.complete(task.getId(),variables);
			/** 第二次设值 end */
			
			return "success";
		}
	}

}
