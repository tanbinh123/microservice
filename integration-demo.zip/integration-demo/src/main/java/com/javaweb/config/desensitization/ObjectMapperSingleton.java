package com.javaweb.config.desensitization;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.AnnotationIntrospector;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.introspect.AnnotationIntrospectorPair;
import com.javaweb.config.desensitization.impl.NameImpl;

/** 使用示例
ObjectMapper objectMapper = new ObjectMapper();
AnnotationIntrospector sis = objectMapper.getSerializationConfig().getAnnotationIntrospector();
AnnotationIntrospector dis = objectMapper.getDeserializationConfig().getAnnotationIntrospector();
AnnotationIntrospector is1 = AnnotationIntrospectorPair.pair(sis,new DesensitizationAnnotationIntrospector());
AnnotationIntrospector is2 = AnnotationIntrospectorPair.pair(dis,new DesensitizationAnnotationIntrospector());
objectMapper.setAnnotationIntrospectors(is1,is2);
objectMapper.writeValueAsString(obj);
*/
public class ObjectMapperSingleton {
	
	public final static Map<DesensitizationTypeEnum,DesensitizationHandler> MAP = new HashMap<>();
	static{
		MAP.put(DesensitizationTypeEnum.NAME,new NameImpl());
	}
	
	private final static ObjectMapper OBJECT_MAPPER = new ObjectMapper();
	
	private ObjectMapperSingleton(){
		
	}
	
	public static ObjectMapper getInstance(){
		AnnotationIntrospector sis = OBJECT_MAPPER.getSerializationConfig().getAnnotationIntrospector();
		AnnotationIntrospector dis = OBJECT_MAPPER.getDeserializationConfig().getAnnotationIntrospector();
		AnnotationIntrospector is1 = AnnotationIntrospectorPair.pair(sis,new DesensitizationAnnotationIntrospector());
		AnnotationIntrospector is2 = AnnotationIntrospectorPair.pair(dis,new DesensitizationAnnotationIntrospector());
		OBJECT_MAPPER.setAnnotationIntrospectors(is1,is2);
		return OBJECT_MAPPER;
	}

}
