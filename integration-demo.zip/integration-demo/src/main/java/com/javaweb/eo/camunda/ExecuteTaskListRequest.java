package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExecuteTaskListRequest implements Serializable {

	private static final long serialVersionUID = 1409252058016074211L;
	
	private String taskId;
	
	private String taskName;

	private String processInstanceId;
	
	private Boolean needMapVariables = true;

	private Integer currentPage = 1;//默认第一页

	private Integer pageSize = 10;//默认每页显示10条
	
}