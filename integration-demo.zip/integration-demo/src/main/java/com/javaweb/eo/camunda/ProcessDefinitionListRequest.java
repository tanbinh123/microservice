package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Setter;

import lombok.Getter;

@Getter
@Setter
public class ProcessDefinitionListRequest implements Serializable {

	private static final long serialVersionUID = 7890122125052646766L;
	
	private String key;//流程图ID（就是id="Process_1wgrhz1"）
	
	private String deploymentId;//流程部署ID
	
	private Integer currentPage = 1;//默认第一页

	private Integer pageSize = 10;//默认每页显示10条

}
