package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProcessInstanceListRequest implements Serializable {

	private static final long serialVersionUID = -9176742092228552247L;
	
	private String processInstanceId;//流程实例ID
	
	private Integer currentPage = 1;//默认第一页

	private Integer pageSize = 10;//默认每页显示10条

}
