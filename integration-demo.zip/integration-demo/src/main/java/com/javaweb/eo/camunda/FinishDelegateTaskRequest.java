package com.javaweb.eo.camunda;

import java.io.Serializable;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FinishDelegateTaskRequest implements Serializable {

	private static final long serialVersionUID = 4922786944474367770L;

	private String taskId;
	
	private Map<String,Object> map;
	
}
