package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeploymentBpmnXmlRequest implements Serializable {

	private static final long serialVersionUID = 7794088934161912328L;

	private String resourceName;
	
	private String xmlContent;
	
}
