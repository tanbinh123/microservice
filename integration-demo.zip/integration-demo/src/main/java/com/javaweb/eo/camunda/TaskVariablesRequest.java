package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaskVariablesRequest implements Serializable {

	private static final long serialVersionUID = -1044572132598659704L;

	private String taskId;
	
}
