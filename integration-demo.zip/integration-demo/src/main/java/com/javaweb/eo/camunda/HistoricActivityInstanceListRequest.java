package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HistoricActivityInstanceListRequest implements Serializable {

	private static final long serialVersionUID = -946234090613947140L;

	private String processInstanceId;
	
	private Integer currentPage = 1;//默认第一页

	private Integer pageSize = 10;//默认每页显示10条

}
