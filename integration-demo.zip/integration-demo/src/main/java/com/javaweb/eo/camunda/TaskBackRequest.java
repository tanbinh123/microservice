package com.javaweb.eo.camunda;

import java.io.Serializable;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaskBackRequest implements Serializable {

	private static final long serialVersionUID = 2354165675038656401L;

	private String processInstanceId;//一般同cancelActivityInstanceId,可以通过获取流程实例列表接口或listProcessInstance方法获取
	
	private String cancelActivityInstanceId;//一般同processInstanceId,可以通过获取流程实例列表接口或listProcessInstance方法获取
	
	private String activityId;
	
	private Map<String,Object> map;
	
}
