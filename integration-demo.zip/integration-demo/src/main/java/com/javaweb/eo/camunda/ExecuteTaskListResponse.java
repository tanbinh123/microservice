package com.javaweb.eo.camunda;

import java.io.Serializable;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExecuteTaskListResponse implements Serializable {

	private static final long serialVersionUID = 461141237679229958L;

	private String id;//任务ID
	
	private String name;
	
	private String createTime;
	
	private String pocessInstanceId;//流程实例ID
	
	private String processDefinitionId;//流程定义ID
	
	private Map<String, Object> map;
	
	private String candidateUsers;
	
	private String candidateGroups;
	
	private Boolean suspendedFlag;
	
	private String owner;
	
	private String assignee;
	
}