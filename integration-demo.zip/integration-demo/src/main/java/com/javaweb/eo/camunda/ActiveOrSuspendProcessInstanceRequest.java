package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ActiveOrSuspendProcessInstanceRequest implements Serializable {

	private static final long serialVersionUID = -8460610820134794985L;

	private String processInstanceId;
	
	private int type;//1：激活；2：挂起
	
}
