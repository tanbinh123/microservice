package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Setter;

import lombok.Getter;

@Getter
@Setter
public class ProcessDefinitionListResponse implements Serializable {

	private static final long serialVersionUID = 7453354586311660435L;
	
	private String id;//流程定义ID
	
	private String deploymentId;//流程部署ID
	
	private String key;//key（可以认为是流程图BPMN中的ID）

	private Integer version;//版本
	
}
