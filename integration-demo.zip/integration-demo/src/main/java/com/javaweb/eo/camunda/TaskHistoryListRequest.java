package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaskHistoryListRequest implements Serializable {

	private static final long serialVersionUID = -5646408712213673184L;

	private int type;//0:：全部历史任务；1：已完成历史任务；2：未完成历史任务
	
	private Integer currentPage = 1;//默认第一页

	private Integer pageSize = 10;//默认每页显示10条

}
