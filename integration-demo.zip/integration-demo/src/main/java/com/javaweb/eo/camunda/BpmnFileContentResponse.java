package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BpmnFileContentResponse implements Serializable{

	private static final long serialVersionUID = 5068148364888704224L;

	private String fileName;
	
	private String fileContent;
	
}
