package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeploymentListResponse implements Serializable {

	private static final long serialVersionUID = -6845251309239084593L;

	private String id;//部署ID

	private String name;

	private String deploymentTime;

	private String source;

	private String tenantId;
	
}
