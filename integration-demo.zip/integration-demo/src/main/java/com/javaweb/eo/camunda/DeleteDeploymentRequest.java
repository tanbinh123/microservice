package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeleteDeploymentRequest implements Serializable {

	private static final long serialVersionUID = 7334186224992663879L;

	private String deploymentId;
	
}
