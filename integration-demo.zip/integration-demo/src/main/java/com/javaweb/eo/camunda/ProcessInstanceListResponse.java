package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProcessInstanceListResponse implements Serializable {

	private static final long serialVersionUID = -5915801353294784207L;
	
	private String businessKey;
	
	private String caseInstanceId;
	
	private String id;
	
	private String processDefinitionId;
	
	private String processInstanceId;
	
	private Boolean suspendedFlag;

}
