package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProcessInstanceByIdResponse implements Serializable {

	private static final long serialVersionUID = 7328432284427786156L;

	private String id;
	
	private String processDefinitionId;//流程定义ID
	
	private String processInstanceId;//流程实例ID
	
	private String businessKey;//业务key
	
}
