package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeploymentListRequest implements Serializable {

	private static final long serialVersionUID = -8893035994684106953L;
	
	private String deploymentId;

	private String deploymentName;
	
	private Integer currentPage = 1;//默认第一页

	private Integer pageSize = 10;//默认每页显示10条
	
}
