package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeleteProcessDefinitionRequest implements Serializable {

	private static final long serialVersionUID = -202495740646497570L;
	
	private String processDefinitionId;
	
}