package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProcessInstanceHistoryListRequest implements Serializable {

	private static final long serialVersionUID = -8118263130298512687L;

	private int type;//0:：全部历史实例；1：已完成历史实例；2：未完成历史实例

	private Integer currentPage = 1;//默认第一页

	private Integer pageSize = 10;//默认每页显示10条
	
}
