package com.javaweb.eo.camunda;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AssigneeTaskRequest implements Serializable {

	private static final long serialVersionUID = -5645482092387316312L;

	private String taskId;
	
	private String userId;
	
}
