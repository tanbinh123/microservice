package com.javaweb.eo.camunda;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProcessInstanceByIdRequest implements Serializable {

	private static final long serialVersionUID = 1543940434835949067L;

	private String processDefinitionId;//流程定义ID
	
	private String businessKey = "BUSINESS_KEY_"+new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());//业务key
	
	private Map<String,Object> map;//请求参数
	
}
