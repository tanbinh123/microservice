package com.javaweb.base;

import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.solr.client.solrj.SolrClient;
import org.camunda.bpm.engine.CaseService;
import org.camunda.bpm.engine.ExternalTaskService;
import org.camunda.bpm.engine.FilterService;
import org.camunda.bpm.engine.FormService;
import org.camunda.bpm.engine.HistoryService;
import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.ManagementService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.RepositoryService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.TaskService;
import org.camunda.bpm.model.dmn.instance.DecisionService;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.client.RestTemplate;

import com.google.code.kaptcha.impl.DefaultKaptcha;
import com.javaweb.config.hbase.HbaseHandleService;
import com.javaweb.config.websocket.WebSocketHandleService;

public class BaseInject {
    
	@Autowired
	protected HbaseHandleService hbaseHandleService;
	
	@Autowired
	protected KafkaConsumer<String,String> kafkaConsumer;
	
	@Autowired
	protected KafkaProducer<String,String> kafkaProduct;
	
	@Autowired
	protected KafkaTemplate<String,String> kafkaTemplate;
	
	@Autowired  
	protected SolrClient solrClient;
	
	@Autowired
	protected MongoTemplate mongoTemplate;
	
	@Autowired
	protected WebSocketHandleService webSocketHandleService;
	
	@Autowired
	protected RestHighLevelClient restHighLevelClient;
	
	@Autowired
	protected DefaultKaptcha defaultKaptcha;
	
	@Autowired
	protected JavaMailSender javaMailSender;
	
	@Autowired
	@Qualifier("redisTemplate1")
	protected StringRedisTemplate stringRedisTemplate1;
	
	@Autowired
	@Qualifier("redisTemplate2")
	protected StringRedisTemplate stringRedisTemplate2;
	
	@Autowired
	protected RestTemplate restTemplate;
	
	/** camunda start */
	@Autowired
	protected ProcessEngine processEngine;
	
	@Autowired
    protected RuntimeService runtimeService;

	@Autowired
	protected TaskService taskService;
	
	@Autowired
	protected RepositoryService repositoryService;
	
	@Autowired
	protected HistoryService historyService;
	
	@Autowired
	protected IdentityService identityService;
	
	@Autowired
	protected FormService formService;
	
	@Autowired
	protected ManagementService managementService;
	
	@Autowired
	protected FilterService filterService;
	
	@Autowired
	protected ExternalTaskService externalTaskService;
	
	@Autowired
	protected CaseService caseService;
	
	@Autowired
	protected DecisionService decisionService;
	/** camunda end */
	
}
