'use strict';
angular.module('webApp').controller('PerformanceMonitorCtrl',function ($scope,$state,$http,$stateParams,Upload) {
	$scope.druidSrc = '../druid';
});
