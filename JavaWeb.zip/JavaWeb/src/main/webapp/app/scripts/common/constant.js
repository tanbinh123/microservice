var PageClass = (function() {
	var innerObject = {};
	innerObject.CURRENT_PAGE = 1;//当前页数,默认第1页
	innerObject.PAGE_SIZE = 10;//每页显示数,默认显示10条
	return innerObject;
})();