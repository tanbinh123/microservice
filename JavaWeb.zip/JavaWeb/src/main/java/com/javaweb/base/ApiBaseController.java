package com.javaweb.base;

public class ApiBaseController {
	
}
