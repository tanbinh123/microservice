package com.javaweb.view.rbac;

public class ScheduleReceiveDataVO {
	
	private String date;
	
	private int scheduleType;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getScheduleType() {
		return scheduleType;
	}

	public void setScheduleType(int scheduleType) {
		this.scheduleType = scheduleType;
	}
	
}
